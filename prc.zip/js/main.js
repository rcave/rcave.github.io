//function checkWidth(init) {
//    /*If browser resized, check width again */
//    if ($(window).width() > 500) {
//        $('nav').show();
//        $('nav').removeClass('active');
//        $('nav ul li').removeClass('dropDown');
//    } else {
//        if (!init) {
//            $('nav').hide();
//            $('nav').removeClass('active');
//            $('nav ul li').addClass('dropDown');
//        }
//    }
//}

//    checkWidth(true);
//
//    $(window).resize(function () {
//        checkWidth(false);
//    });


//wait for animation to allow hover




$('document').ready(function () {

    setTimeout(function () {

        $('#rcLogoDiv').hide(800);
        $('#nameSwitch').css('display', 'block');

    }, 3000);

    if ($(window).width() > 575) {
        $('.anchor').removeClass('anchor');
        $('.hexTop').addClass('topAni');
        $('.hexMid').addClass('midAni');
        $('.hexBot').addClass('botAni');
    }

    if ($(window).width() < 575) {
        $('.hexTop').removeClass('topAni');
        $('.hexMid').removeClass('midAni');
        $('.hexBot').removeClass('botAni');
    }

    $('#hamMen').click(function () {

        if ($('#hamMen').hasClass('takeOver')) {
            $('#navTakeOver').slideUp(1000);
            setTimeout(function () {
                $('#hamMenuLinks').hide();
            }, 1000);
            $('#hamMen').removeClass('takeOver');
            $('#hamMen div').css('background', '#fff');

            if ($(window).width() < 575) {
                setTimeout(function () {
                    $('.menCon').css('background', '#000');
                }, 1000);
            }
        } else {
            $('#hamMenuLinks').show();
            $('#navTakeOver').slideDown(1000);
            $('#hamMen').addClass('takeOver');
            $('#hamMen div').css('background', '#000');
            $('.menCon').css('background', 'none');
        }
    });



    $('.hexLinks li a').click(function () {
        $('#navTakeOver').slideUp(1000);
        setTimeout(function () {
            $('#hamMenuLinks').hide();
        }, 1000);
        $('#hamMen').removeClass('takeOver');
        $('#hamMen div').css('background', '#fff');

        if ($(window).width() < 575) {
            setTimeout(function () {
                $('.menCon').css('background', '#000');
            }, 1000);
        }
    });
});